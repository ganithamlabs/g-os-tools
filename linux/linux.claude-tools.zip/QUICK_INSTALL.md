# One-Line Installation Commands

## 🚀 Fastest Installation (Recommended)

```bash
# Create installation directory, copy files, set permissions, and configure shell
mkdir -p ~/.local/bin/claude-tools && \
cd ~/.local/bin/claude-tools && \
# (Place your downloaded files here first) && \
chmod +x *.sh && \
mkdir -p ~/.local/bin && \
ln -sf ~/.local/bin/claude-tools/claude-context-manager.sh ~/.local/bin/claude-save && \
ln -sf ~/.local/bin/claude-tools/claude-context-loader.sh ~/.local/bin/claude-load && \
ln -sf ~/.local/bin/claude-tools/claude-context-switcher.sh ~/.local/bin/claude-switch && \
ln -sf ~/.local/bin/claude-tools/claude-project-init.sh ~/.local/bin/claude-init && \
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc && \
echo 'source ~/.local/bin/claude-tools/shell-config.sh' >> ~/.bashrc && \
source ~/.bashrc && \
echo "✅ Installation complete! Run: claude-init"
```

## 📋 Step-by-Step Quick Install

### 1. Download Files

Save all the scripts to a temporary location:

```bash
# Create temporary download directory
mkdir -p ~/downloads/claude-tools
cd ~/downloads/claude-tools

# Download or copy all .sh files here:
# - claude-context-manager.sh
# - claude-context-loader.sh  
# - claude-context-switcher.sh
# - claude-project-init.sh
# - shell-config.sh
# - install.sh (optional - automated installer)
```

### 2. Run Automated Installer

```bash
cd ~/downloads/claude-tools
chmod +x install.sh
./install.sh
```

That's it! The installer handles everything.

### 3. OR Manual Quick Install

```bash
# Install to user directory
mkdir -p ~/.local/bin/claude-tools
cp ~/downloads/claude-tools/*.sh ~/.local/bin/claude-tools/
chmod +x ~/.local/bin/claude-tools/*.sh

# Create command shortcuts
mkdir -p ~/.local/bin
ln -sf ~/.local/bin/claude-tools/claude-context-manager.sh ~/.local/bin/claude-save
ln -sf ~/.local/bin/claude-tools/claude-context-loader.sh ~/.local/bin/claude-load
ln -sf ~/.local/bin/claude-tools/claude-context-switcher.sh ~/.local/bin/claude-switch
ln -sf ~/.local/bin/claude-tools/claude-project-init.sh ~/.local/bin/claude-init

# Add to shell (choose one)
# For Bash:
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
echo 'source ~/.local/bin/claude-tools/shell-config.sh' >> ~/.bashrc
source ~/.bashrc

# For Zsh:
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc
echo 'source ~/.local/bin/claude-tools/shell-config.sh' >> ~/.zshrc
source ~/.zshrc

# Verify
claude-save --help
```

## 🎯 Minimal Installation (No Shell Integration)

Just want the scripts without changing your shell config?

```bash
# Install to home bin
mkdir -p ~/bin/claude-tools
cp ~/downloads/claude-tools/*.sh ~/bin/claude-tools/
chmod +x ~/bin/claude-tools/*.sh

# Use with full paths
~/bin/claude-tools/claude-context-manager.sh
~/bin/claude-tools/claude-context-loader.sh
~/bin/claude-tools/claude-project-init.sh
```

## 🐚 Shell-Specific Instructions

### Bash
```bash
cat >> ~/.bashrc << 'EOF'

# Claude Code Context Management
export PATH="$HOME/.local/bin:$PATH"
alias claude-save='~/.local/bin/claude-tools/claude-context-manager.sh'
alias claude-load='~/.local/bin/claude-tools/claude-context-loader.sh'
alias claude-init='~/.local/bin/claude-tools/claude-project-init.sh'
EOF

source ~/.bashrc
```

### Zsh
```bash
cat >> ~/.zshrc << 'EOF'

# Claude Code Context Management  
export PATH="$HOME/.local/bin:$PATH"
alias claude-save='~/.local/bin/claude-tools/claude-context-manager.sh'
alias claude-load='~/.local/bin/claude-tools/claude-context-loader.sh'
alias claude-init='~/.local/bin/claude-tools/claude-project-init.sh'
EOF

source ~/.zshrc
```

### Fish
```bash
# Add to ~/.config/fish/config.fish
echo 'set -gx PATH $HOME/.local/bin $PATH' >> ~/.config/fish/config.fish
echo 'alias claude-save="~/.local/bin/claude-tools/claude-context-manager.sh"' >> ~/.config/fish/config.fish
echo 'alias claude-load="~/.local/bin/claude-tools/claude-context-loader.sh"' >> ~/.config/fish/config.fish
echo 'alias claude-init="~/.local/bin/claude-tools/claude-project-init.sh"' >> ~/.config/fish/config.fish

source ~/.config/fish/config.fish
```

## ✅ Verify Installation

```bash
# Check commands are available
which claude-save
which claude-load
which claude-init

# Test help
claude-init --help

# Check version
ls -la ~/.local/bin/claude-tools/

# Test in a project
cd ~/projects/test-project
claude-init
```

## 🔄 Quick Update

```bash
# Replace old files with new ones
cp ~/downloads/claude-tools/*.sh ~/.local/bin/claude-tools/
chmod +x ~/.local/bin/claude-tools/*.sh

# Reload shell
source ~/.bashrc  # or ~/.zshrc
```

## 🗑️ Quick Uninstall

```bash
# Remove everything
rm -rf ~/.local/bin/claude-tools
rm -f ~/.local/bin/claude-{save,load,switch,init}
rm -f ~/.claude-projects.conf

# Remove from shell config
# Edit ~/.bashrc or ~/.zshrc and delete the Claude section

# Reload
source ~/.bashrc  # or ~/.zshrc
```

## 💡 First Use

After installation:

```bash
# Initialize your first project
cd ~/projects/my-project
claude-init

# Edit the instructions
nano .claude/instructions.md

# Start working
./claude-resume.sh
```

## 🆘 Common Issues

### "Command not found"
```bash
# Add to PATH manually
export PATH="$HOME/.local/bin:$PATH"

# Or use full path
~/.local/bin/claude-save
```

### "Permission denied"
```bash
# Fix permissions
chmod +x ~/.local/bin/claude-tools/*.sh
```

### Commands work but context doesn't load
```bash
# Check Claude transcript directory exists
mkdir -p ~/.claude/transcripts

# Check project has transcripts
ls claude_transcripts/

# Try manual load
~/.local/bin/claude-tools/claude-context-loader.sh
```

## 📦 Installation from Git (If using version control)

```bash
# Clone repository (if you create one)
git clone https://github.com/yourusername/claude-tools.git ~/.local/bin/claude-tools

# Make executable
chmod +x ~/.local/bin/claude-tools/*.sh

# Create symlinks
cd ~/.local/bin
ln -sf claude-tools/claude-context-manager.sh claude-save
ln -sf claude-tools/claude-context-loader.sh claude-load
ln -sf claude-tools/claude-context-switcher.sh claude-switch
ln -sf claude-tools/claude-project-init.sh claude-init

# Configure shell
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc

# Update later
cd ~/.local/bin/claude-tools
git pull
```

## 🎓 What Gets Installed

### Files Created
```
~/.local/bin/claude-tools/          # Main directory
├── claude-context-manager.sh       # Save context
├── claude-context-loader.sh        # Load context
├── claude-context-switcher.sh      # Multi-project manager
├── claude-project-init.sh          # Initialize projects
└── shell-config.sh                 # Shell integration

~/.local/bin/                       # Symlinks
├── claude-save -> claude-tools/claude-context-manager.sh
├── claude-load -> claude-tools/claude-context-loader.sh
├── claude-switch -> claude-tools/claude-context-switcher.sh
└── claude-init -> claude-tools/claude-project-init.sh

~/.bashrc or ~/.zshrc               # Shell config (modified)
~/.claude-projects.conf             # Project list (created later)
```

### Shell Modifications
Your `~/.bashrc` or `~/.zshrc` will have this added:
```bash
# Claude Code Context Management
export PATH="$HOME/.local/bin:$PATH"
source ~/.local/bin/claude-tools/shell-config.sh
```
