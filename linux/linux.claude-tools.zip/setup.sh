#!/bin/bash

# Claude Code Context Management - One-Command Setup
# This script checks for files and installs everything in one go

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_header() {
    echo -e "${BLUE}╔════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║   Claude Code Context - Complete Setup        ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════╝${NC}"
    echo ""
}

print_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_step() { echo -e "${BLUE}[STEP]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check if required files exist
check_files() {
    local missing=0
    local files=(
        "claude-context-manager.sh"
        "claude-context-loader.sh"
        "claude-context-switcher.sh"
        "claude-project-init.sh"
    )
    
    print_step "Checking for required files..."
    
    for file in "${files[@]}"; do
        if [ -f "$file" ]; then
            echo -e "${GREEN}✓${NC} $file"
        else
            echo -e "${RED}✗${NC} $file ${RED}(MISSING!)${NC}"
            ((missing++))
        fi
    done
    
    echo ""
    
    if [ $missing -gt 0 ]; then
        print_error "$missing required file(s) missing!"
        echo ""
        echo "Please make sure you have all these files in the current directory:"
        echo "  - claude-context-manager.sh"
        echo "  - claude-context-loader.sh"
        echo "  - claude-context-switcher.sh"
        echo "  - claude-project-init.sh"
        echo ""
        echo "Current directory: $(pwd)"
        echo "Files present: $(ls -1 *.sh 2>/dev/null | wc -l) .sh files"
        echo ""
        exit 1
    fi
    
    print_info "All required files found!"
}

# Make scripts executable
make_executable() {
    print_step "Making scripts executable..."
    chmod +x *.sh 2>/dev/null || chmod +x claude-*.sh
    print_info "Scripts are now executable"
}

# Quick install
quick_install() {
    local install_dir="$HOME/.local/bin/claude-tools"
    
    print_step "Installing to: $install_dir"
    
    # Create directory
    mkdir -p "$install_dir"
    
    # Copy scripts
    cp claude-*.sh "$install_dir/" 2>/dev/null || true
    cp shell-config.sh "$install_dir/" 2>/dev/null || true
    cp *.md "$install_dir/" 2>/dev/null || true
    
    # Make executable
    chmod +x "$install_dir"/*.sh
    
    print_info "Files installed to: $install_dir"
    
    # Create symlinks
    print_step "Creating command shortcuts..."
    mkdir -p "$HOME/.local/bin"
    
    ln -sf "$install_dir/claude-context-manager.sh" "$HOME/.local/bin/claude-save"
    ln -sf "$install_dir/claude-context-loader.sh" "$HOME/.local/bin/claude-load"
    ln -sf "$install_dir/claude-context-switcher.sh" "$HOME/.local/bin/claude-switch"
    ln -sf "$install_dir/claude-project-init.sh" "$HOME/.local/bin/claude-init"
    
    print_info "Commands created: claude-save, claude-load, claude-switch, claude-init"
    
    # Setup shell
    setup_shell_quick
}

# Quick shell setup
setup_shell_quick() {
    print_step "Setting up shell integration..."
    
    # Detect shell
    local shell_config=""
    if [ -n "$ZSH_VERSION" ] || [ -f "$HOME/.zshrc" ]; then
        shell_config="$HOME/.zshrc"
    elif [ -n "$BASH_VERSION" ] || [ -f "$HOME/.bashrc" ]; then
        shell_config="$HOME/.bashrc"
    else
        shell_config="$HOME/.profile"
    fi
    
    # Check if already configured
    if grep -q "Claude Code Context Management" "$shell_config" 2>/dev/null; then
        print_warning "Shell already configured in $shell_config"
        return
    fi
    
    # Add configuration
    cat >> "$shell_config" << 'EOF'

# ============================================================================
# Claude Code Context Management
# ============================================================================
export PATH="$HOME/.local/bin:$PATH"

# Aliases
alias claude-save='~/.local/bin/claude-tools/claude-context-manager.sh'
alias claude-load='~/.local/bin/claude-tools/claude-context-loader.sh'
alias claude-init='~/.local/bin/claude-tools/claude-project-init.sh'
alias claude-switch='~/.local/bin/claude-tools/claude-context-switcher.sh'

# Optional: source full shell integration
# source ~/.local/bin/claude-tools/shell-config.sh

# Project directory
export CLAUDE_PROJECTS_DIR="$HOME/projects"
# ============================================================================
EOF
    
    print_info "Added configuration to: $shell_config"
}

# Show completion message
show_completion() {
    echo ""
    echo "╔════════════════════════════════════════════════╗"
    echo "║         Installation Complete! 🎉              ║"
    echo "╚════════════════════════════════════════════════╝"
    echo ""
    print_info "Commands installed:"
    echo "  • claude-save   - Save project context"
    echo "  • claude-load   - Load project context"
    echo "  • claude-init   - Initialize a project"
    echo "  • claude-switch - Manage multiple projects"
    echo ""
    print_step "Activate now:"
    
    if [ -f "$HOME/.zshrc" ]; then
        echo "  ${GREEN}source ~/.zshrc${NC}"
    else
        echo "  ${GREEN}source ~/.bashrc${NC}"
    fi
    
    echo ""
    print_step "Or restart your terminal"
    echo ""
    print_step "First steps:"
    echo "  1. cd /path/to/your/project"
    echo "  2. claude-init"
    echo "  3. edit .claude/instructions.md"
    echo "  4. ./claude-resume.sh"
    echo ""
    print_info "Full documentation: ~/.local/bin/claude-tools/COMPLETE_GUIDE.md"
    echo ""
}

# Main setup
main() {
    print_header
    
    # Check we're in the right directory
    if [ ! -f "claude-context-manager.sh" ] && [ ! -f "claude-context-loader.sh" ]; then
        print_error "Required scripts not found in current directory!"
        echo ""
        echo "Please run this script from the directory containing the downloaded files."
        echo "Current directory: $(pwd)"
        echo ""
        echo "Files found:"
        ls -1 *.sh 2>/dev/null || echo "  (no .sh files found)"
        echo ""
        exit 1
    fi
    
    # Run setup steps
    check_files
    echo ""
    
    make_executable
    echo ""
    
    quick_install
    echo ""
    
    show_completion
}

main "$@"
