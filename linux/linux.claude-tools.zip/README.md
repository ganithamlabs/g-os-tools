# Claude Code Context Manager

Manage Claude Code conversation context across multiple repositories.

## Problem

When using Claude Code on multiple projects, the conversation history and context from one project can interfere with another. This tool helps you:

1. Extract and save Claude Code transcripts for each repository
2. Commit them to the repository for future reference
3. Reset Claude Code's context before switching projects

## Installation

### Quick Setup

```bash
# Download the scripts
curl -o ~/claude-context-manager.sh https://raw.githubusercontent.com/YOUR_REPO/claude-context-manager.sh
curl -o ~/claude-context-switcher.sh https://raw.githubusercontent.com/YOUR_REPO/claude-context-switcher.sh

# Make them executable
chmod +x ~/claude-context-manager.sh
chmod +x ~/claude-context-switcher.sh

# Optional: Add to PATH
sudo ln -s ~/claude-context-manager.sh /usr/local/bin/claude-save
sudo ln -s ~/claude-context-switcher.sh /usr/local/bin/claude-switch
```

### Manual Installation

1. Copy the scripts to your home directory or anywhere in your PATH
2. Make them executable: `chmod +x *.sh`

## Usage

### Option 1: Simple Single-Project Manager

Use `claude-context-manager.sh` for quick, one-off context saves:

```bash
# Save context for current repository
cd /path/to/your/project
./claude-context-manager.sh

# Save context for specific repository
./claude-context-manager.sh /path/to/project

# Save context for multiple repositories
./claude-context-manager.sh /path/to/project1 /path/to/project2
```

This will:
- Create `claude_transcripts/` folder in the repository
- Extract relevant transcripts to that folder
- Commit the changes
- Optionally reset Claude Code context

### Option 2: Multi-Project Switcher

Use `claude-context-switcher.sh` for managing multiple projects:

```bash
# 1. Initialize configuration
./claude-context-switcher.sh --init

# 2. Add your projects
./claude-context-switcher.sh --add /home/user/projects/project1
./claude-context-switcher.sh --add /home/user/projects/project2
./claude-context-switcher.sh --add /home/user/work/api-service

# 3. List configured projects
./claude-context-switcher.sh --list

# 4. Process all projects at once
./claude-context-switcher.sh --all

# 5. Process single project
./claude-context-switcher.sh --single /path/to/project

# 6. Reset Claude context only
./claude-context-switcher.sh --reset
```

## Workflow

### Daily Workflow

```bash
# End of day - save all project contexts
claude-switch --all

# This will:
# - Go through each configured project
# - Extract transcripts to claude_transcripts/
# - Commit changes to each repository
# - Reset Claude context at the end
```

### Project Switch Workflow

```bash
# Finishing work on project A
cd ~/projects/project-a
claude-save

# Starting work on project B (with clean context)
cd ~/projects/project-b
claudecode
```

## What Gets Saved?

Each repository will have a `claude_transcripts/` directory containing:

```
claude_transcripts/
├── README.md                    # Info about the transcripts
├── transcript_20240215_143022.json
├── transcript_20240215_151534.json
└── ...
```

These JSON files contain:
- Full conversation history with Claude Code
- Commands executed
- Files modified
- Context about the project

## Configuration File

The multi-project switcher uses `~/.claude-projects.conf`:

```bash
# Example configuration
/home/user/projects/my-app
/home/user/work/api-service
/home/user/personal/website
```

## Customization

### Filtering Transcripts

By default, the script tries to match transcripts by repository path. To customize:

Edit the `extract_transcripts` function in the script to adjust filtering logic.

### Auto-commit Message

Customize the commit message by editing the `commit_changes` function:

```bash
git commit -m "Your custom message"
```

### Transcript Location

Claude Code stores transcripts in `~/.claude/transcripts/`. If your setup is different:

```bash
# Edit this variable in the scripts:
claude_transcript_path="$HOME/.claude/transcripts"
```

## Integration with Git Hooks

### Pre-checkout Hook

Automatically save context when switching branches:

```bash
# .git/hooks/pre-checkout
#!/bin/bash
~/claude-context-manager.sh $(git rev-parse --show-toplevel)
```

### Daily Cron Job

Automatically save all project contexts daily:

```bash
# Add to crontab (crontab -e)
0 18 * * * ~/claude-context-switcher.sh --all
```

## Troubleshooting

### No transcripts found

- Check if `~/.claude/transcripts/` exists
- Verify you've had conversations with Claude Code in this repository
- Try copying all transcripts when prompted

### Git commit fails

- Ensure you're in a git repository
- Check git status: `git status`
- Verify you have commit permissions

### Context not resetting

- Manually check: `ls ~/.claude/transcripts/`
- Backup is created before reset: `~/.claude/transcripts_backup_*`
- Restart Claude Code after reset

## Best Practices

1. **Save context before switching projects**: Always run the script before moving to a different repository
2. **Commit meaningful transcripts**: Review what's being committed
3. **Use .gitignore if needed**: Add `claude_transcripts/` to `.gitignore` if you don't want to version control transcripts
4. **Regular cleanup**: Periodically review and clean old transcripts
5. **Backup important conversations**: The reset is permanent, so save important transcripts first

## Advanced: Selective Transcript Save

If you want to manually select which transcripts to save:

```bash
# List available transcripts
ls -lh ~/.claude/transcripts/

# Manually copy specific ones
cp ~/.claude/transcripts/transcript_SPECIFIC.json ./claude_transcripts/
```

## FAQ

**Q: Will this delete my conversation history?**  
A: Yes, when you reset. But it backs up to `~/.claude/transcripts_backup_*` first.

**Q: Can I recover transcripts after reset?**  
A: Yes, from the backup directory or from the committed `claude_transcripts/` folders.

**Q: Do I need to commit the transcripts?**  
A: No, but it's useful for team collaboration and historical reference.

**Q: How often should I reset context?**  
A: Whenever you switch between unrelated projects or feel the context is polluted.

## License

MIT - Feel free to modify and distribute.

## Contributing

Improvements welcome! Especially:
- Better transcript filtering
- Integration with other tools
- Platform-specific adaptations (Windows, macOS)
