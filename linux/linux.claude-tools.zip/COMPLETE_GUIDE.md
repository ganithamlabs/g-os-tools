# Complete Claude Code Context Management Guide

## 🎯 The Problem

When using Claude Code across multiple projects, context from one project bleeds into another. You want:
1. **Save** Claude's understanding of each project
2. **Load** the right context when you switch projects
3. **Isolate** each project's conversation history

## ✨ The Solution

A complete workflow with shell integration and native Claude config files.

---

## 🚀 Quick Setup

### 1. Install Scripts

```bash
# Download and install scripts
cd ~
chmod +x claude-context-manager.sh
chmod +x claude-context-loader.sh
chmod +x claude-context-switcher.sh
chmod +x claude-project-init.sh

# Optional: add to PATH
sudo ln -s ~/claude-context-manager.sh /usr/local/bin/claude-save
sudo ln -s ~/claude-context-loader.sh /usr/local/bin/claude-load
sudo ln -s ~/claude-project-init.sh /usr/local/bin/claude-init
```

### 2. Configure Your Shell

Add to `~/.bashrc` or `~/.zshrc`:

```bash
# Source the Claude configuration
source ~/shell-config.sh
```

Or manually add just the essentials:

```bash
# Claude Code context management aliases
alias claude-save='~/claude-context-manager.sh'
alias claude-load='~/claude-context-loader.sh'
alias claude-init='~/claude-project-init.sh'

# Quick project switcher
work() {
    cd ~/projects/"$1" && claude-load && claudecode
}
```

### 3. Initialize Your First Project

```bash
cd /path/to/your/project
claude-init

# This creates:
# - .claude/instructions.md (tell Claude about your project)
# - claude_transcripts/ (saved conversations)
# - claude-resume.sh (quick start script)
```

---

## 📖 Complete Workflow

### Starting a New Project

```bash
# Navigate to project
cd ~/projects/my-new-project

# Initialize Claude context management
claude-init

# Edit the instructions file
nano .claude/instructions.md

# Start coding with Claude
claudecode
```

### Daily Work on a Single Project

```bash
# Option 1: Use the project's quick start script
cd ~/projects/my-project
./claude-resume.sh

# Option 2: Manual load
cd ~/projects/my-project
claude-load
claudecode
```

### Switching Between Projects

```bash
# Finish working on Project A
cd ~/projects/project-a
claude-save    # Saves context to claude_transcripts/

# Switch to Project B
cd ~/projects/project-b
claude-load    # Loads Project B's context
claudecode     # Start coding with Project B context
```

### End of Day - Save All Projects

```bash
# Save context for all projects at once
claude-context-switcher.sh --all

# This will:
# - Visit each configured project
# - Extract and save transcripts
# - Commit changes
# - Reset Claude's context
```

---

## 🗂️ Project Structure

After initialization, your project looks like this:

```
my-project/
├── .claude/
│   ├── instructions.md        # ⭐ Edit this! Tell Claude about your project
│   └── PROJECT_CONTEXT.md      # Auto-generated guide
├── claude_transcripts/
│   ├── README.md               # Info about transcripts
│   ├── transcript_*.json       # Saved conversations
│   └── CONTEXT_SUMMARY.md      # High-level overview (auto-created)
├── claude-resume.sh            # Quick start script
└── [your project files]
```

---

## 📝 Custom Instructions (.claude/instructions.md)

This is the **most important file**. Claude reads it every time. Here's what to include:

```markdown
# Project: My Awesome App

## Overview
A web application for managing tasks with AI assistance.

## Tech Stack
- **Frontend:** React 18, TypeScript, Tailwind CSS
- **Backend:** Node.js, Express, PostgreSQL
- **Deployment:** Vercel

## Architecture
- Use functional components with hooks
- Follow atomic design principles
- API calls through dedicated service layer

## Current Focus
Working on user authentication with JWT tokens.

## Important Context for Claude

**Always:**
- Use TypeScript with strict mode
- Write tests for new features
- Follow conventional commits

**Never:**
- Use class components (prefer functional)
- Directly manipulate DOM
- Hardcode API URLs

## Common Tasks

### Start Development
\`\`\`bash
npm run dev
\`\`\`

### Run Tests
\`\`\`bash
npm test
\`\`\`

### Deploy
\`\`\`bash
npm run build && vercel deploy
\`\`\`
```

---

## 🔧 Shell Integration Options

### Option 1: Automatic Context Loading (Recommended)

Add to `~/.bashrc` or `~/.zshrc`:

```bash
# Auto-load context when entering a project
load_claude_context_auto() {
    if git rev-parse --git-dir > /dev/null 2>&1; then
        local repo_root=$(git rev-parse --show-toplevel)
        if [ -d "$repo_root/claude_transcripts" ]; then
            if [ "$CLAUDE_CONTEXT_LOADED" != "$repo_root" ]; then
                echo "💡 Claude context available. Run: claude-load"
            fi
        fi
    fi
}

# For bash
PROMPT_COMMAND="${PROMPT_COMMAND:+$PROMPT_COMMAND$'\n'}load_claude_context_auto"

# For zsh
autoload -U add-zsh-hook
add-zsh-hook chpwd load_claude_context_auto
```

### Option 2: Enhanced cd Command

```bash
cdc() {
    cd "$@"
    if [ -d "claude_transcripts" ]; then
        claude-load
    fi
}
```

### Option 3: Project Aliases

```bash
# Define shortcuts for your main projects
alias api='cd ~/projects/api && claude-load && claudecode'
alias web='cd ~/projects/website && claude-load && claudecode'
alias cli='cd ~/projects/cli-tool && claude-load && claudecode'
```

### Option 4: Project Switcher Function

```bash
work() {
    local project="${1}"
    
    if [ -z "$project" ]; then
        echo "Projects:"
        ls ~/projects
        return
    fi
    
    # Save current context
    if git rev-parse --git-dir > /dev/null 2>&1; then
        claude-save
    fi
    
    # Switch and load new context
    cd ~/projects/"$project"
    claude-load
    claudecode
}

# Usage:
# work my-api
# work website
```

---

## 🎨 Advanced Usage

### Multi-Project Context Save

```bash
# Configure projects
./claude-context-switcher.sh --init
./claude-context-switcher.sh --add ~/projects/project1
./claude-context-switcher.sh --add ~/projects/project2
./claude-context-switcher.sh --add ~/work/api-service

# Save all at once
./claude-context-switcher.sh --all
```

### View Context Status

```bash
# Add this function to your shell config
claude-status() {
    local transcripts=$(find ~/.claude/transcripts -name "*.json" 2>/dev/null | wc -l)
    echo "Active transcripts: $transcripts"
    
    if git rev-parse --git-dir > /dev/null 2>&1; then
        local repo=$(basename $(git rev-parse --show-toplevel))
        local saved=$(find claude_transcripts -name "*.json" 2>/dev/null | wc -l)
        echo "Current project: $repo"
        echo "Saved transcripts: $saved"
    fi
}
```

### Scheduled Auto-Save

Add to crontab (`crontab -e`):

```bash
# Save all projects every day at 6 PM
0 18 * * * ~/claude-context-switcher.sh --all
```

### Git Hooks Integration

Create `.git/hooks/post-checkout`:

```bash
#!/bin/bash
# Auto-load context after checkout

if [ -d "claude_transcripts" ]; then
    echo "🔄 New branch detected. Reloading Claude context..."
    ~/claude-context-loader.sh
fi
```

---

## 💡 Best Practices

### 1. Keep Instructions Updated

Whenever you make important decisions or adopt new patterns:

```bash
cd ~/projects/my-project
nano .claude/instructions.md
# Add the new decision/pattern
git commit -am "docs: update Claude instructions with new auth pattern"
```

### 2. Save Context Before Switching

Always save before switching projects:

```bash
# Bad: Just switch
cd ~/other-project

# Good: Save then switch
claude-save && cd ~/other-project && claude-load
```

### 3. Use Meaningful Commit Messages

When the scripts commit transcripts:

```bash
# The script does this automatically:
git commit -m "chore: save Claude Code transcripts before context switch"
```

### 4. Review Transcripts Periodically

```bash
# Check what's been saved
ls -lh claude_transcripts/

# Review specific transcript
cat claude_transcripts/transcript_20240215_143022.json | jq
```

### 5. Clean Old Transcripts

```bash
# Remove transcripts older than 30 days
find claude_transcripts -name "*.json" -mtime +30 -delete
```

---

## 🔍 Troubleshooting

### Context Not Loading

**Problem:** `claude-load` runs but Claude doesn't seem to have context.

**Solutions:**
1. Check transcript directory exists: `ls claude_transcripts/`
2. Verify transcripts were copied: `ls ~/.claude/transcripts/`
3. Restart Claude Code after loading
4. Check `.claude/instructions.md` is properly formatted

### Transcripts Not Saving

**Problem:** `claude-save` doesn't create any files.

**Solutions:**
1. Check Claude transcript location: `ls ~/.claude/transcripts/`
2. Verify you've had conversations with Claude Code
3. Check permissions on directories
4. Try manual copy: `cp ~/.claude/transcripts/*.json ./claude_transcripts/`

### Scripts Not Found

**Problem:** `claude-save: command not found`

**Solutions:**
1. Use full path: `~/claude-context-manager.sh`
2. Check permissions: `chmod +x ~/claude-*.sh`
3. Verify alias in shell config: `alias | grep claude`
4. Reload shell config: `source ~/.bashrc`

### Git Commit Fails

**Problem:** Script errors during commit step.

**Solutions:**
1. Ensure you're in a git repo: `git status`
2. Check if there are changes: `git status claude_transcripts/`
3. Manually commit: `git add claude_transcripts && git commit -m "save transcripts"`

---

## 📚 Reference

### All Commands

```bash
# Initialization
claude-init                    # Initialize current project
claude-init /path/to/project   # Initialize specific project

# Context Management
claude-save                    # Save current project context
claude-load                    # Load current project context
claude-status                  # Show context status

# Multi-Project
claude-context-switcher.sh --init         # Setup config
claude-context-switcher.sh --add PATH     # Add project
claude-context-switcher.sh --list         # List projects
claude-context-switcher.sh --all          # Process all projects

# Quick Start
./claude-resume.sh             # Project-specific quick start
work <project-name>            # Shell function to switch projects
```

### File Locations

```
~/.claude/transcripts/              # Active Claude Code transcripts
~/.claude-projects.conf             # Multi-project configuration
~/claude-*.sh                       # Management scripts
~/shell-config.sh                   # Shell integration config

<project>/.claude/instructions.md   # Project-specific instructions
<project>/claude_transcripts/       # Saved project transcripts
<project>/claude-resume.sh          # Quick start script
```

---

## 🎓 Example Workflows

### Scenario 1: Freelancer with Multiple Client Projects

```bash
# Morning: Start work on Client A's API
work client-a-api

# Afternoon: Switch to Client B's website
claude-save
work client-b-website

# End of day: Save everything
claude-context-switcher.sh --all
```

### Scenario 2: Full-Stack Developer

```bash
# Morning: Frontend work
cd ~/projects/frontend
claude-load
claudecode

# Afternoon: Backend work
cd ~/projects/backend
claude-load
claudecode
```

### Scenario 3: Open Source Maintainer

```bash
# Work on project 1
cd ~/oss/project1
./claude-resume.sh

# Review PR, switch to project 2
claude-save
cd ~/oss/project2
claude-load
```

---

## 🤝 Contributing & Customization

Feel free to customize these scripts! Common customizations:

1. **Change transcript directory name:** Edit `claude_transcripts` to `.claude/transcripts`
2. **Add auto-commit hooks:** Integrate with your CI/CD
3. **Custom filtering:** Modify transcript filtering logic
4. **Integration with IDEs:** Create IDE-specific plugins

---

## 📄 License

MIT - Use freely, modify as needed!
