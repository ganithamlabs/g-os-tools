# Claude Code Auto-Context Loader
# Add this to your shell configuration (~/.bashrc, ~/.zshrc, etc.)

# ============================================================================
# OPTION 1: Automatic context loading when changing directories
# ============================================================================

# Function to load Claude context when entering a git repository
load_claude_context_auto() {
    # Only run if we're in a git repository
    if git rev-parse --git-dir > /dev/null 2>&1; then
        local repo_root=$(git rev-parse --show-toplevel)
        local transcript_dir="$repo_root/claude_transcripts"
        
        # Check if this repo has saved context
        if [ -d "$transcript_dir" ] && [ -n "$(find "$transcript_dir" -name "*.json" 2>/dev/null)" ]; then
            # Only load if not already loaded for this repo
            if [ "$CLAUDE_CONTEXT_LOADED" != "$repo_root" ]; then
                echo "🔄 Claude Code context available for this project"
                read -p "Load context? [y/N]: " -n 1 -r
                echo
                if [[ $REPLY =~ ^[Yy]$ ]]; then
                    ~/claude-context-loader.sh
                    export CLAUDE_CONTEXT_LOADED="$repo_root"
                fi
            fi
        fi
    fi
}

# Hook into directory change (for bash)
if [ -n "$BASH_VERSION" ]; then
    PROMPT_COMMAND="${PROMPT_COMMAND:+$PROMPT_COMMAND$'\n'}load_claude_context_auto"
fi

# Hook into directory change (for zsh)
if [ -n "$ZSH_VERSION" ]; then
    autoload -U add-zsh-hook
    add-zsh-hook chpwd load_claude_context_auto
fi

# ============================================================================
# OPTION 2: Manual command aliases
# ============================================================================

# Quick command to load context for current project
alias claude-load='~/claude-context-loader.sh'

# Quick command to save current context
alias claude-save='~/claude-context-manager.sh'

# Combined workflow: save old context, switch to new project, load new context
alias claude-switch='~/claude-context-manager.sh && cd "$@" && ~/claude-context-loader.sh'

# ============================================================================
# OPTION 3: Project-specific aliases (add your projects here)
# ============================================================================

# Example project shortcuts that automatically load context
alias work-api='cd ~/projects/api-service && ~/claude-context-loader.sh && claudecode'
alias work-frontend='cd ~/projects/frontend-app && ~/claude-context-loader.sh && claudecode'
alias personal='cd ~/personal/website && ~/claude-context-loader.sh && claudecode'

# ============================================================================
# OPTION 4: Enhanced 'cd' command with context awareness
# ============================================================================

# Wrapper around cd that auto-loads context
claude_cd() {
    builtin cd "$@"
    
    # Check if we entered a git repo with Claude context
    if git rev-parse --git-dir > /dev/null 2>&1; then
        local repo_root=$(git rev-parse --show-toplevel)
        local transcript_dir="$repo_root/claude_transcripts"
        
        if [ -d "$transcript_dir" ]; then
            echo "💡 This project has saved Claude context"
            echo "   Run: claude-load"
        fi
    fi
}

# Uncomment to use enhanced cd (or use 'cdc' command)
# alias cd='claude_cd'
alias cdc='claude_cd'

# ============================================================================
# OPTION 5: Project workspace switcher
# ============================================================================

# Switch to a project and start Claude Code with context
work() {
    local project="$1"
    local projects_dir="${CLAUDE_PROJECTS_DIR:-$HOME/projects}"
    
    if [ -z "$project" ]; then
        echo "Available projects:"
        ls -1 "$projects_dir"
        return 1
    fi
    
    local project_path="$projects_dir/$project"
    
    if [ ! -d "$project_path" ]; then
        echo "Project not found: $project"
        return 1
    fi
    
    # Save current context if in a project
    if git rev-parse --git-dir > /dev/null 2>&1; then
        echo "💾 Saving current project context..."
        ~/claude-context-manager.sh
    fi
    
    # Switch to new project
    cd "$project_path"
    
    # Load new context
    echo "📂 Loading context for: $project"
    ~/claude-context-loader.sh
    
    # Start Claude Code
    echo ""
    read -p "Start Claude Code? [Y/n]: " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Nn]$ ]]; then
        claudecode
    fi
}

# Autocomplete for work command (bash)
if [ -n "$BASH_VERSION" ]; then
    _work_completion() {
        local projects_dir="${CLAUDE_PROJECTS_DIR:-$HOME/projects}"
        COMPREPLY=($(compgen -W "$(ls -1 $projects_dir 2>/dev/null)" -- "${COMP_WORDS[1]}"))
    }
    complete -F _work_completion work
fi

# ============================================================================
# Configuration Variables
# ============================================================================

# Set your main projects directory
export CLAUDE_PROJECTS_DIR="$HOME/projects"

# Set path to scripts (adjust if needed)
export CLAUDE_SCRIPTS_DIR="$HOME"

# ============================================================================
# Utility Functions
# ============================================================================

# List all projects with Claude context
claude-projects() {
    echo "Projects with saved Claude context:"
    echo ""
    
    local projects_dir="${CLAUDE_PROJECTS_DIR:-$HOME/projects}"
    
    for dir in "$projects_dir"/*; do
        if [ -d "$dir/claude_transcripts" ]; then
            local count=$(find "$dir/claude_transcripts" -name "*.json" 2>/dev/null | wc -l)
            echo "  📁 $(basename "$dir") ($count transcripts)"
        fi
    done
}

# Show current Claude context status
claude-status() {
    local claude_dir="$HOME/.claude/transcripts"
    local transcript_count=$(find "$claude_dir" -name "*.json" 2>/dev/null | wc -l)
    
    echo "Claude Code Context Status:"
    echo ""
    echo "  Active transcripts: $transcript_count"
    echo "  Transcript directory: $claude_dir"
    
    if git rev-parse --git-dir > /dev/null 2>&1; then
        local repo_root=$(git rev-parse --show-toplevel)
        local repo_name=$(basename "$repo_root")
        echo "  Current project: $repo_name"
        
        if [ -d "$repo_root/claude_transcripts" ]; then
            local saved_count=$(find "$repo_root/claude_transcripts" -name "*.json" 2>/dev/null | wc -l)
            echo "  Saved transcripts: $saved_count"
        else
            echo "  Saved transcripts: 0 (no context saved)"
        fi
    fi
}

# ============================================================================
# End of Claude Code Configuration
# ============================================================================

# Show helpful message on shell startup (comment out if annoying)
echo "💡 Claude Code context management loaded"
echo "   Commands: claude-load, claude-save, claude-status, work <project>"
