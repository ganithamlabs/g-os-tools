#!/bin/bash

# Claude Code Context Manager
# This script extracts Claude Code transcripts for a repository,
# saves them to claude_transcripts/, resets Claude, and commits changes

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored messages
print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if we're in a git repository
check_git_repo() {
    if ! git rev-parse --git-dir > /dev/null 2>&1; then
        print_error "Not in a git repository!"
        exit 1
    fi
}

# Function to get the repository root
get_repo_root() {
    git rev-parse --show-toplevel
}

# Function to extract Claude Code transcripts
extract_transcripts() {
    local repo_path="$1"
    local repo_name=$(basename "$repo_path")
    local transcript_dir="$repo_path/claude_transcripts"
    
    print_info "Extracting transcripts for: $repo_name"
    
    # Create transcript directory if it doesn't exist
    mkdir -p "$transcript_dir"
    
    # Claude Code stores transcripts in ~/.claude/transcripts
    local claude_transcript_path="$HOME/.claude/transcripts"
    
    if [ ! -d "$claude_transcript_path" ]; then
        print_warning "Claude transcript directory not found at $claude_transcript_path"
        return 1
    fi
    
    # Find transcripts that mention this repository path
    # This is a heuristic - adjust based on how Claude Code names transcripts
    local count=0
    
    # Copy all recent transcripts (you may want to filter these better)
    for transcript in "$claude_transcript_path"/*.json; do
        if [ -f "$transcript" ]; then
            # Check if transcript mentions this repo path
            if grep -q "$repo_path" "$transcript" 2>/dev/null; then
                cp "$transcript" "$transcript_dir/"
                ((count++))
            fi
        fi
    done
    
    # If no specific matches, offer to copy all transcripts
    if [ $count -eq 0 ]; then
        print_warning "No transcripts found matching this repository path"
        read -p "Copy all Claude transcripts to this project? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            cp "$claude_transcript_path"/*.json "$transcript_dir/" 2>/dev/null || true
            count=$(ls -1 "$transcript_dir"/*.json 2>/dev/null | wc -l)
        fi
    fi
    
    print_info "Extracted $count transcript(s) to $transcript_dir"
    
    # Create a README in the transcript directory
    cat > "$transcript_dir/README.md" << EOF
# Claude Code Transcripts

This directory contains Claude Code conversation transcripts for this project.

- **Extracted on**: $(date)
- **Repository**: $repo_name
- **Number of transcripts**: $count

## Files

These JSON files contain the conversation history with Claude Code for this repository.
You can review them to see the context and decisions made during development.
EOF
    
    return 0
}

# Function to reset Claude Code
reset_claude() {
    print_info "Resetting Claude Code context..."
    
    # The main way to reset is to clear the transcripts
    local claude_transcript_path="$HOME/.claude/transcripts"
    
    if [ -d "$claude_transcript_path" ]; then
        # Backup before clearing (optional)
        local backup_path="$HOME/.claude/transcripts_backup_$(date +%Y%m%d_%H%M%S)"
        print_info "Creating backup at: $backup_path"
        cp -r "$claude_transcript_path" "$backup_path"
        
        # Clear transcripts
        rm -rf "$claude_transcript_path"/*
        print_info "Claude Code transcripts cleared"
    else
        print_warning "Claude transcript directory not found"
    fi
}

# Function to commit changes
commit_changes() {
    local repo_path="$1"
    cd "$repo_path"
    
    print_info "Committing transcript changes..."
    
    # Check if there are changes to commit
    if [ -n "$(git status --porcelain claude_transcripts/)" ]; then
        git add claude_transcripts/
        git commit -m "chore: save Claude Code transcripts before context switch

- Extracted conversation history to claude_transcripts/
- Preparing to switch Claude Code context to different project"
        print_info "Changes committed successfully"
    else
        print_warning "No changes to commit"
    fi
}

# Function to process a single repository
process_repository() {
    local repo_path="$1"
    
    if [ ! -d "$repo_path" ]; then
        print_error "Repository path does not exist: $repo_path"
        return 1
    fi
    
    cd "$repo_path"
    check_git_repo
    
    local repo_name=$(basename "$repo_path")
    echo ""
    echo "========================================="
    print_info "Processing: $repo_name"
    echo "========================================="
    
    # Extract transcripts
    if extract_transcripts "$repo_path"; then
        # Commit changes
        commit_changes "$repo_path"
    else
        print_warning "Skipping commit for $repo_name"
    fi
}

# Main function
main() {
    echo "Claude Code Context Manager"
    echo "==========================="
    echo ""
    
    # Check for arguments
    if [ $# -eq 0 ]; then
        # No arguments - process current repository
        print_info "No repository paths provided. Processing current directory..."
        process_repository "$(get_repo_root)"
        
        # Reset Claude after processing
        read -p "Reset Claude Code context now? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            reset_claude
        fi
    else
        # Process each repository provided
        for repo in "$@"; do
            process_repository "$repo"
        done
        
        # Reset Claude after processing all repositories
        read -p "All repositories processed. Reset Claude Code context now? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            reset_claude
        fi
    fi
    
    echo ""
    print_info "Done! You can now switch to your next project with a clean context."
}

# Run main function
main "$@"
