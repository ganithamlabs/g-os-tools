# Claude Code Custom Instructions Template

This file should be placed in your project root as `.claude/instructions.md` or `.claudecode`
Claude Code will automatically read this file and use it as context.

---

# Project: [PROJECT_NAME]

## Project Overview

**Description:** [Brief description of what this project does]

**Type:** [Web app / API / CLI tool / Library / etc.]

**Status:** [Active development / Maintenance / Prototype]

## Tech Stack

**Languages:** 
- [Primary language and version]
- [Other languages]

**Frameworks:**
- [Main framework]
- [Supporting frameworks]

**Dependencies:**
- [Key libraries]
- [Build tools]

**Infrastructure:**
- [Database]
- [Hosting/deployment]
- [Other services]

## Project Structure

```
project-root/
├── src/                 # [Description]
├── tests/               # [Description]
├── docs/                # [Description]
├── scripts/             # [Description]
└── claude_transcripts/  # Saved Claude Code conversations
```

**Important Directories:**
- `[directory]` - [purpose]
- `[directory]` - [purpose]

**Key Files:**
- `[file]` - [purpose]
- `[file]` - [purpose]

## Development Workflow

**Setup:**
```bash
# Commands to set up the project
npm install
# or
pip install -r requirements.txt
```

**Running:**
```bash
# Commands to run the project
npm start
# or
python main.py
```

**Testing:**
```bash
# Commands to run tests
npm test
# or
pytest
```

**Building:**
```bash
# Commands to build
npm run build
```

## Coding Conventions

**Style Guide:** [ESLint / PEP8 / etc.]

**Naming Conventions:**
- Files: [snake_case / kebab-case / PascalCase]
- Variables: [camelCase / snake_case]
- Classes: [PascalCase]
- Constants: [UPPER_CASE]

**Code Organization:**
- [Principle 1]
- [Principle 2]

**Comments:**
- [When and how to comment]

## Architecture Decisions

### Design Patterns
- [Pattern used]: [Why and where]

### State Management
- [How state is handled]

### Data Flow
- [How data moves through the system]

### Authentication/Authorization
- [How auth is implemented]

## Current Focus

**Active Tasks:**
1. [Task description]
2. [Task description]
3. [Task description]

**Recently Completed:**
- [Completed work]
- [Completed work]

**Next Steps:**
- [ ] [Next task]
- [ ] [Next task]

## Important Context for Claude

**Things Claude Should Know:**
- [Important decision or constraint]
- [Pattern to follow]
- [Common pitfall to avoid]

**Things Claude Should NOT Do:**
- ❌ [Anti-pattern to avoid]
- ❌ [Library not to use]
- ❌ [Approach to avoid]

**Preferred Approaches:**
- ✅ [Pattern Claude should use]
- ✅ [Tool Claude should prefer]
- ✅ [Style Claude should follow]

## Common Tasks & Commands

### Task: [Common task name]
```bash
# Commands for this task
command here
```

### Task: [Another common task]
```bash
# Commands for this task
command here
```

## Known Issues & Gotchas

**Issue:** [Description of issue]
- **Workaround:** [How to handle it]
- **Status:** [Being tracked / Known limitation]

**Issue:** [Another issue]
- **Workaround:** [Solution]

## Dependencies & Related Projects

**Related Repositories:**
- [repo-name]: [Purpose]
- [repo-name]: [Purpose]

**External Services:**
- [Service]: [How it's used]
- [Service]: [How it's used]

## Testing Guidelines

**Test Coverage:** [Current coverage goal]

**Testing Approach:**
- Unit tests: [When and what to test]
- Integration tests: [Scope]
- E2E tests: [Scope]

**Test Data:**
- [Where test data lives]
- [How to generate test data]

## Deployment

**Environments:**
- Development: [Details]
- Staging: [Details]
- Production: [Details]

**Deployment Process:**
1. [Step 1]
2. [Step 2]
3. [Step 3]

## Team Conventions

**Commit Messages:**
- Format: [conventional commits / other]
- Example: `feat: add user authentication`

**Branch Naming:**
- Format: [feature/name, fix/name, etc.]
- Example: `feature/user-auth`

**PR Guidelines:**
- [What to include in PRs]
- [Review process]

## Resources & Documentation

**Documentation:**
- [Link to docs]
- [Link to wiki]

**Design Files:**
- [Link to Figma / other]

**API Documentation:**
- [Link to API docs]

## Context from Previous Sessions

[This section is auto-updated by claude-context-loader.sh]

**Last Session:** [Date]
**Work Completed:** [Summary]
**Current State:** [Where we left off]

---

## Instructions for Claude Code

When working on this project:

1. **Read** the saved transcripts in `claude_transcripts/` to understand previous decisions
2. **Follow** the coding conventions and architecture patterns described above
3. **Ask** if you're unsure about any project-specific decisions
4. **Update** this file if you learn something important about the project
5. **Reference** the Known Issues section before proposing solutions

**Remember:**
- [Key thing Claude should always remember]
- [Another important reminder]
- [Final important point]

---

**Last Updated:** [Date]
**Updated By:** [Your name]
