#!/bin/bash

# File Verification Script for Claude Code Context Management
# Run this to verify all required files are present

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_header() {
    echo "╔════════════════════════════════════════════════╗"
    echo "║   Claude Code Context - File Verification     ║"
    echo "╚════════════════════════════════════════════════╝"
    echo ""
}

check_file() {
    local file="$1"
    local required="$2"
    
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓${NC} $file"
        return 0
    else
        if [ "$required" = "required" ]; then
            echo -e "${RED}✗${NC} $file ${RED}(REQUIRED - MISSING!)${NC}"
            return 1
        else
            echo -e "${YELLOW}○${NC} $file (optional - not found)"
            return 0
        fi
    fi
}

print_header

echo "Checking required files..."
echo ""

# Track if any required files are missing
MISSING=0

# Required scripts
echo "Core Scripts:"
check_file "claude-context-manager.sh" "required" || ((MISSING++))
check_file "claude-context-loader.sh" "required" || ((MISSING++))
check_file "claude-context-switcher.sh" "required" || ((MISSING++))
check_file "claude-project-init.sh" "required" || ((MISSING++))
echo ""

# Shell integration
echo "Shell Integration:"
check_file "shell-config.sh" "optional"
echo ""

# Documentation
echo "Documentation:"
check_file "README.md" "optional"
check_file "COMPLETE_GUIDE.md" "optional"
check_file "DEPLOYMENT_GUIDE.md" "optional"
check_file "QUICK_INSTALL.md" "optional"
echo ""

# Templates
echo "Templates:"
check_file "project-instructions-template.md" "optional"
echo ""

# Installer
echo "Installer:"
check_file "install.sh" "optional"
echo ""

echo "════════════════════════════════════════════════"

if [ $MISSING -eq 0 ]; then
    echo -e "${GREEN}✓ All required files present!${NC}"
    echo ""
    echo "Next steps:"
    echo "  1. chmod +x *.sh"
    echo "  2. ./install.sh"
    echo ""
else
    echo -e "${RED}✗ $MISSING required file(s) missing!${NC}"
    echo ""
    echo "Please download the missing files:"
    echo ""
    echo "Required files:"
    echo "  - claude-context-manager.sh"
    echo "  - claude-context-loader.sh"
    echo "  - claude-context-switcher.sh"
    echo "  - claude-project-init.sh"
    echo ""
    exit 1
fi
