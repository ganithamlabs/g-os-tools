#!/bin/bash

# Claude Code Context Loader
# Restores Claude Code context from saved transcripts when entering a project

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_step() { echo -e "${BLUE}[STEP]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }

# Get repository root
get_repo_root() {
    git rev-parse --show-toplevel 2>/dev/null || echo "$(pwd)"
}

# Load context for current project
load_context() {
    local repo_path=$(get_repo_root)
    local repo_name=$(basename "$repo_path")
    local transcript_dir="$repo_path/claude_transcripts"
    
    print_step "Loading context for: $repo_name"
    
    # Check if transcript directory exists
    if [ ! -d "$transcript_dir" ]; then
        print_warning "No saved transcripts found at: $transcript_dir"
        print_info "This appears to be a fresh project for Claude Code"
        return 0
    fi
    
    # Count available transcripts
    local transcript_count=$(find "$transcript_dir" -name "*.json" 2>/dev/null | wc -l)
    
    if [ "$transcript_count" -eq 0 ]; then
        print_warning "No transcript files found in: $transcript_dir"
        return 0
    fi
    
    print_info "Found $transcript_count saved transcript(s)"
    
    # Restore transcripts to Claude directory
    local claude_dir="$HOME/.claude/transcripts"
    mkdir -p "$claude_dir"
    
    # Clear existing transcripts first (optional - comment out if you want to merge)
    print_step "Clearing current Claude context..."
    rm -f "$claude_dir"/*.json
    
    # Copy project transcripts back
    print_step "Restoring project transcripts..."
    cp "$transcript_dir"/*.json "$claude_dir/" 2>/dev/null || {
        print_warning "Failed to copy some transcripts"
    }
    
    print_info "Context restored! Claude Code now has access to previous conversations."
    
    # Show transcript info
    if [ -f "$transcript_dir/README.md" ]; then
        echo ""
        echo "📋 Project Context Info:"
        head -n 10 "$transcript_dir/README.md" | tail -n +2
    fi
    
    echo ""
    print_info "You can now run: claudecode"
}

# Create context loading instructions
create_context_summary() {
    local repo_path=$(get_repo_root)
    local transcript_dir="$repo_path/claude_transcripts"
    
    if [ ! -d "$transcript_dir" ]; then
        return 0
    fi
    
    # Create a summary file that Claude can read
    local summary_file="$transcript_dir/CONTEXT_SUMMARY.md"
    
    cat > "$summary_file" << EOF
# Project Context Summary

**Repository:** $(basename "$repo_path")
**Last Context Save:** $(date)
**Transcript Count:** $(find "$transcript_dir" -name "*.json" | wc -l)

## Quick Project Overview

This is automatically generated when you load context. Add your project-specific notes below:

### Key Information Claude Should Know

- **Project Type:** [Add description]
- **Tech Stack:** [Add details]
- **Current Focus:** [What you're working on]
- **Important Decisions:** [Any architectural choices]
- **Conventions:** [Coding standards, naming conventions]

### Recent Work

[Describe what was accomplished in previous sessions]

### Next Steps

[What needs to be done next]

### Important Files

- 
- 
- 

### Gotchas / Known Issues

- 
- 

---

**Note:** Claude Code will read this file along with the restored transcripts.
Update this file to help Claude understand the project context better.
EOF
    
    print_info "Created context summary: $summary_file"
    print_info "Edit this file to add project-specific guidance for Claude"
}

# Main
main() {
    local repo_path=$(get_repo_root)
    
    echo "╔════════════════════════════════════════════════╗"
    echo "║     Claude Code Context Loader                ║"
    echo "╚════════════════════════════════════════════════╝"
    echo ""
    
    load_context
    
    # Create or update context summary
    create_context_summary
    
    echo ""
    echo "════════════════════════════════════════════════"
    print_info "Ready to work with Claude Code!"
    echo ""
    echo "💡 Tip: Claude will remember your previous conversations"
    echo "💡 Run 'claudecode' to start coding with context"
    echo "════════════════════════════════════════════════"
}

main "$@"
