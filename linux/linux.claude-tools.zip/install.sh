#!/bin/bash

# Claude Code Context Management - Installation Script
# This script installs all components and sets up your environment

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_header() {
    echo -e "${BLUE}╔════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║     Claude Code Context Management Setup      ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════╝${NC}"
    echo ""
}

print_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_step() { echo -e "${BLUE}[STEP]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Detect shell
detect_shell() {
    if [ -n "$ZSH_VERSION" ]; then
        echo "zsh"
    elif [ -n "$BASH_VERSION" ]; then
        echo "bash"
    else
        echo "unknown"
    fi
}

# Get shell config file
get_shell_config() {
    local shell_type=$(detect_shell)
    
    if [ "$shell_type" = "zsh" ]; then
        echo "$HOME/.zshrc"
    elif [ "$shell_type" = "bash" ]; then
        if [ -f "$HOME/.bashrc" ]; then
            echo "$HOME/.bashrc"
        else
            echo "$HOME/.bash_profile"
        fi
    else
        echo "$HOME/.profile"
    fi
}

# Installation directory options
show_install_options() {
    echo "Choose installation location:"
    echo ""
    echo "  1) $HOME/.local/bin/claude-tools/  (Recommended - user only)"
    echo "  2) $HOME/bin/                      (Simple - user only)"
    echo "  3) /usr/local/bin/                 (System-wide - requires sudo)"
    echo "  4) Custom directory"
    echo ""
    read -p "Enter choice [1]: " choice
    choice=${choice:-1}
    
    case $choice in
        1)
            echo "$HOME/.local/bin/claude-tools"
            ;;
        2)
            echo "$HOME/bin"
            ;;
        3)
            echo "/usr/local/bin"
            ;;
        4)
            read -p "Enter custom path: " custom_path
            echo "$custom_path"
            ;;
        *)
            echo "$HOME/.local/bin/claude-tools"
            ;;
    esac
}

# Create installation directory
create_install_dir() {
    local install_dir="$1"
    
    print_step "Creating installation directory: $install_dir"
    
    if [[ "$install_dir" == /usr/* ]] || [[ "$install_dir" == /opt/* ]]; then
        # System directory - needs sudo
        sudo mkdir -p "$install_dir"
        print_info "Created (with sudo): $install_dir"
    else
        # User directory
        mkdir -p "$install_dir"
        print_info "Created: $install_dir"
    fi
}

# Copy scripts to installation directory
install_scripts() {
    local install_dir="$1"
    local source_dir="$2"
    
    print_step "Installing scripts..."
    
    local scripts=(
        "claude-context-manager.sh"
        "claude-context-loader.sh"
        "claude-context-switcher.sh"
        "claude-project-init.sh"
    )
    
    local use_sudo=false
    if [[ "$install_dir" == /usr/* ]] || [[ "$install_dir" == /opt/* ]]; then
        use_sudo=true
    fi
    
    for script in "${scripts[@]}"; do
        if [ -f "$source_dir/$script" ]; then
            if [ "$use_sudo" = true ]; then
                sudo cp "$source_dir/$script" "$install_dir/"
                sudo chmod +x "$install_dir/$script"
            else
                cp "$source_dir/$script" "$install_dir/"
                chmod +x "$install_dir/$script"
            fi
            print_info "Installed: $script"
        else
            print_warning "Script not found: $script"
        fi
    done
    
    # Copy shell config
    if [ -f "$source_dir/shell-config.sh" ]; then
        if [ "$use_sudo" = true ]; then
            sudo cp "$source_dir/shell-config.sh" "$install_dir/"
        else
            cp "$source_dir/shell-config.sh" "$install_dir/"
        fi
        print_info "Installed: shell-config.sh"
    fi
    
    # Copy templates
    if [ -f "$source_dir/project-instructions-template.md" ]; then
        if [ "$use_sudo" = true ]; then
            sudo cp "$source_dir/project-instructions-template.md" "$install_dir/"
        else
            cp "$source_dir/project-instructions-template.md" "$install_dir/"
        fi
        print_info "Installed: project-instructions-template.md"
    fi
}

# Create symbolic links for easy access
create_symlinks() {
    local install_dir="$1"
    
    print_step "Creating command aliases..."
    
    local bin_dir="$HOME/.local/bin"
    mkdir -p "$bin_dir"
    
    # Create symlinks
    ln -sf "$install_dir/claude-context-manager.sh" "$bin_dir/claude-save" 2>/dev/null && \
        print_info "Created command: claude-save"
    
    ln -sf "$install_dir/claude-context-loader.sh" "$bin_dir/claude-load" 2>/dev/null && \
        print_info "Created command: claude-load"
    
    ln -sf "$install_dir/claude-context-switcher.sh" "$bin_dir/claude-switch" 2>/dev/null && \
        print_info "Created command: claude-switch"
    
    ln -sf "$install_dir/claude-project-init.sh" "$bin_dir/claude-init" 2>/dev/null && \
        print_info "Created command: claude-init"
    
    # Check if bin directory is in PATH
    if [[ ":$PATH:" != *":$bin_dir:"* ]]; then
        print_warning "$bin_dir is not in your PATH"
        print_info "Commands will be available after shell restart"
        NEED_PATH_UPDATE=true
    fi
}

# Setup shell integration
setup_shell_integration() {
    local install_dir="$1"
    local shell_config=$(get_shell_config)
    
    print_step "Setting up shell integration..."
    
    # Check if already configured
    if grep -q "Claude Code Context Management" "$shell_config" 2>/dev/null; then
        print_warning "Shell integration already configured in $shell_config"
        read -p "Overwrite? [y/N]: " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            return
        fi
    fi
    
    # Add configuration to shell config
    cat >> "$shell_config" << EOF

# ============================================================================
# Claude Code Context Management
# ============================================================================

# Add scripts to PATH
export PATH="\$HOME/.local/bin:\$PATH"

# Source shell integration
if [ -f "$install_dir/shell-config.sh" ]; then
    source "$install_dir/shell-config.sh"
fi

# Quick aliases (if not already defined in shell-config.sh)
alias claude-save='$install_dir/claude-context-manager.sh'
alias claude-load='$install_dir/claude-context-loader.sh'
alias claude-switch='$install_dir/claude-context-switcher.sh'
alias claude-init='$install_dir/claude-project-init.sh'

# Project directory (customize this!)
export CLAUDE_PROJECTS_DIR="\$HOME/projects"

# ============================================================================
EOF
    
    print_info "Added configuration to: $shell_config"
    print_info "Source it now: source $shell_config"
}

# Verify Claude Code installation
verify_claude_code() {
    print_step "Verifying Claude Code installation..."
    
    if command -v claudecode &> /dev/null; then
        print_info "✓ Claude Code is installed"
        return 0
    else
        print_warning "Claude Code not found in PATH"
        print_info "Install from: https://docs.claude.com/claude-code"
        return 1
    fi
}

# Setup initial configuration
setup_initial_config() {
    print_step "Setting up initial configuration..."
    
    # Initialize multi-project config
    local config_file="$HOME/.claude-projects.conf"
    
    if [ ! -f "$config_file" ]; then
        cat > "$config_file" << 'EOF'
# Claude Code Projects Configuration
# Add your project paths here, one per line
# Example:
# /home/user/projects/my-app
# /home/user/work/api-service

EOF
        print_info "Created config file: $config_file"
        
        # Offer to add current projects
        echo ""
        read -p "Add your projects directory to config? [Y/n]: " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Nn]$ ]]; then
            read -p "Enter projects directory [$HOME/projects]: " projects_dir
            projects_dir=${projects_dir:-$HOME/projects}
            
            if [ -d "$projects_dir" ]; then
                # Add all subdirectories as projects
                for dir in "$projects_dir"/*; do
                    if [ -d "$dir" ]; then
                        echo "$dir" >> "$config_file"
                    fi
                done
                print_info "Added projects from: $projects_dir"
            fi
        fi
    else
        print_info "Config file already exists: $config_file"
    fi
}

# Show post-installation instructions
show_instructions() {
    local install_dir="$1"
    local shell_config=$(get_shell_config)
    
    echo ""
    echo "╔════════════════════════════════════════════════╗"
    echo "║           Installation Complete! 🎉            ║"
    echo "╚════════════════════════════════════════════════╝"
    echo ""
    echo "📁 Installation directory: $install_dir"
    echo "📝 Shell configuration: $shell_config"
    echo ""
    echo "🚀 Next Steps:"
    echo ""
    echo "1. Reload your shell configuration:"
    echo "   ${GREEN}source $shell_config${NC}"
    echo ""
    echo "2. Initialize your first project:"
    echo "   ${GREEN}cd /path/to/your/project${NC}"
    echo "   ${GREEN}claude-init${NC}"
    echo ""
    echo "3. Start working with Claude Code:"
    echo "   ${GREEN}./claude-resume.sh${NC}"
    echo "   ${GREEN}# or${NC}"
    echo "   ${GREEN}claude-load && claudecode${NC}"
    echo ""
    echo "📚 Available Commands:"
    echo "   ${BLUE}claude-init${NC}    - Initialize a project"
    echo "   ${BLUE}claude-save${NC}    - Save current context"
    echo "   ${BLUE}claude-load${NC}    - Load project context"
    echo "   ${BLUE}claude-switch${NC}  - Manage multiple projects"
    echo ""
    echo "💡 Tips:"
    echo "   - Edit .claude/instructions.md in each project"
    echo "   - Use 'work <project>' to quickly switch projects"
    echo "   - Run 'claude-switch --all' to save all projects"
    echo ""
    echo "📖 Full documentation: $install_dir/COMPLETE_GUIDE.md"
    echo ""
    
    if [ "$NEED_PATH_UPDATE" = true ]; then
        echo "⚠️  Remember to restart your shell or run:"
        echo "   source $shell_config"
        echo ""
    fi
}

# Main installation flow
main() {
    print_header
    
    # Determine source directory (where the scripts are currently located)
    local source_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    
    print_info "Installation wizard for Claude Code Context Management"
    echo ""
    
    # Step 1: Choose installation directory
    local install_dir=$(show_install_options)
    echo ""
    
    # Step 2: Create directory
    create_install_dir "$install_dir"
    echo ""
    
    # Step 3: Install scripts
    install_scripts "$install_dir" "$source_dir"
    echo ""
    
    # Step 4: Create symlinks
    create_symlinks "$install_dir"
    echo ""
    
    # Step 5: Setup shell integration
    read -p "Setup shell integration (recommended)? [Y/n]: " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Nn]$ ]]; then
        setup_shell_integration "$install_dir"
    fi
    echo ""
    
    # Step 6: Verify Claude Code
    verify_claude_code
    echo ""
    
    # Step 7: Initial configuration
    read -p "Setup initial project configuration? [Y/n]: " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Nn]$ ]]; then
        setup_initial_config
    fi
    echo ""
    
    # Step 8: Show instructions
    show_instructions "$install_dir"
}

# Run main installation
main "$@"
