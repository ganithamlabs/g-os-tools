#!/bin/bash

# Claude Code Multi-Project Context Switcher
# Manages context switching across multiple repositories

set -e

CONFIG_FILE="$HOME/.claude-projects.conf"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
print_step() { echo -e "${BLUE}[STEP]${NC} $1"; }

# Initialize config file
init_config() {
    if [ ! -f "$CONFIG_FILE" ]; then
        cat > "$CONFIG_FILE" << 'EOF'
# Claude Code Projects Configuration
# Add your project paths here, one per line
# Example:
# /home/user/projects/my-app
# /home/user/work/api-service
# /home/user/personal/website

EOF
        print_info "Created config file at: $CONFIG_FILE"
        print_info "Please add your project paths to this file"
        exit 0
    fi
}

# Read projects from config
read_projects() {
    if [ ! -f "$CONFIG_FILE" ]; then
        print_warning "Config file not found. Run with --init first"
        return 1
    fi
    
    # Read non-empty, non-comment lines
    grep -v '^#' "$CONFIG_FILE" | grep -v '^[[:space:]]*$' || true
}

# Process all projects
process_all_projects() {
    local projects=($(read_projects))
    
    if [ ${#projects[@]} -eq 0 ]; then
        print_warning "No projects found in config file: $CONFIG_FILE"
        exit 1
    fi
    
    print_info "Found ${#projects[@]} project(s) to process"
    echo ""
    
    for project in "${projects[@]}"; do
        if [ -d "$project" ]; then
            bash "$0" --single "$project"
        else
            print_warning "Project directory not found: $project"
        fi
        echo ""
    done
    
    # Reset Claude after all projects
    read -p "All projects processed. Reset Claude Code context? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        reset_claude_context
    fi
}

# Reset Claude context
reset_claude_context() {
    print_step "Resetting Claude Code context..."
    
    local claude_dir="$HOME/.claude/transcripts"
    
    if [ -d "$claude_dir" ]; then
        local backup_dir="$HOME/.claude/transcripts_backup_$(date +%Y%m%d_%H%M%S)"
        print_info "Backing up to: $backup_dir"
        cp -r "$claude_dir" "$backup_dir"
        rm -rf "$claude_dir"/*
        print_info "Context reset complete"
    else
        print_warning "Claude directory not found"
    fi
}

# Process single project
process_single_project() {
    local project_path="$1"
    
    cd "$project_path"
    local project_name=$(basename "$project_path")
    
    print_step "Processing: $project_name"
    
    # Create transcript directory
    mkdir -p "claude_transcripts"
    
    # Extract transcripts
    local claude_dir="$HOME/.claude/transcripts"
    if [ -d "$claude_dir" ]; then
        local count=0
        for transcript in "$claude_dir"/*.json; do
            if [ -f "$transcript" ]; then
                if grep -q "$project_path" "$transcript" 2>/dev/null || [ $count -eq 0 ]; then
                    cp "$transcript" "claude_transcripts/"
                    ((count++))
                fi
            fi
        done
        print_info "Extracted $count transcript(s)"
    fi
    
    # Create README
    cat > "claude_transcripts/README.md" << EOF
# Claude Code Transcripts - $project_name

Extracted on: $(date)

This directory contains conversation transcripts with Claude Code for this project.
EOF
    
    # Commit if in git repo
    if git rev-parse --git-dir > /dev/null 2>&1; then
        if [ -n "$(git status --porcelain claude_transcripts/)" ]; then
            git add claude_transcripts/
            git commit -m "chore: save Claude Code transcripts

- Extracted conversation history
- Preparing for context switch" || print_warning "Commit failed"
            print_info "Changes committed"
        fi
    fi
}

# Show help
show_help() {
    cat << 'EOF'
Claude Code Multi-Project Context Switcher

Usage:
  ./claude-context-switcher.sh [OPTIONS]

Options:
  --init              Create initial config file
  --all               Process all projects in config
  --single PATH       Process single project
  --add PATH          Add project to config
  --list              List configured projects
  --reset             Reset Claude context only
  --help              Show this help

Examples:
  # Initialize
  ./claude-context-switcher.sh --init
  
  # Add projects
  ./claude-context-switcher.sh --add /path/to/project1
  ./claude-context-switcher.sh --add /path/to/project2
  
  # Process all projects and reset
  ./claude-context-switcher.sh --all
  
  # Process single project
  ./claude-context-switcher.sh --single /path/to/project

Config file location: ~/.claude-projects.conf
EOF
}

# Main
case "${1:-}" in
    --init)
        init_config
        ;;
    --all)
        process_all_projects
        ;;
    --single)
        if [ -z "$2" ]; then
            echo "Error: --single requires a path"
            exit 1
        fi
        process_single_project "$2"
        ;;
    --add)
        if [ -z "$2" ]; then
            echo "Error: --add requires a path"
            exit 1
        fi
        init_config
        echo "$2" >> "$CONFIG_FILE"
        print_info "Added: $2"
        ;;
    --list)
        init_config
        echo "Configured projects:"
        read_projects
        ;;
    --reset)
        reset_claude_context
        ;;
    --help|*)
        show_help
        ;;
esac
