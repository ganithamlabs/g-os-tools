# Claude Code Context Management - File Manifest

## Required Files (Must Have)

These files are essential for the tools to work:

### Core Scripts
1. **claude-context-manager.sh** - Saves context before switching projects
   - Extracts transcripts from ~/.claude/transcripts/
   - Creates claude_transcripts/ in project
   - Commits changes to git

2. **claude-context-loader.sh** - Loads context when resuming work
   - Copies transcripts from claude_transcripts/ to ~/.claude/transcripts/
   - Creates context summary
   - Shows project info

3. **claude-context-switcher.sh** - Manages multiple projects
   - Processes all configured projects
   - Batch save/load operations
   - Configuration management

4. **claude-project-init.sh** - Initializes new projects
   - Creates .claude/ directory
   - Creates claude_transcripts/ directory
   - Generates instruction templates
   - Creates quick-start script

## Optional Files (Recommended)

### Shell Integration
5. **shell-config.sh** - Shell integration and aliases
   - Auto-load context on directory change
   - Project switcher functions
   - Convenient aliases
   - Status commands

### Installation
6. **install.sh** - Automated installer
   - Guided installation wizard
   - Multiple installation options
   - Shell configuration setup
   - Verification checks

### Documentation
7. **README.md** - Basic overview and quick start
8. **COMPLETE_GUIDE.md** - Comprehensive usage guide
9. **DEPLOYMENT_GUIDE.md** - Installation instructions
10. **QUICK_INSTALL.md** - One-liner installation commands

### Templates
11. **project-instructions-template.md** - Template for .claude/instructions.md

## File Checklist

Before running install.sh, verify you have these files:

```bash
# Run this in your download directory:
ls -1

# You should see:
# ✓ claude-context-manager.sh
# ✓ claude-context-loader.sh
# ✓ claude-context-switcher.sh
# ✓ claude-project-init.sh
# ○ shell-config.sh (optional)
# ○ install.sh (optional)
# ○ verify-files.sh (optional)
# ○ *.md files (optional docs)
```

## Quick File Check

Run the verification script:

```bash
chmod +x verify-files.sh
./verify-files.sh
```

## If Files Are Missing

### Download All Files

If you're missing files, make sure you have downloaded all of these from the outputs:

1. claude-context-manager.sh
2. claude-context-loader.sh
3. claude-context-switcher.sh
4. claude-project-init.sh
5. shell-config.sh
6. install.sh
7. verify-files.sh
8. All .md documentation files

### Minimum Installation

If you only want the essentials:

```bash
# Just download these 4 files:
claude-context-manager.sh
claude-context-loader.sh
claude-context-switcher.sh
claude-project-init.sh

# Then install manually:
mkdir -p ~/.local/bin/claude-tools
cp claude-*.sh ~/.local/bin/claude-tools/
chmod +x ~/.local/bin/claude-tools/*.sh

# Create aliases in ~/.bashrc:
alias claude-save='~/.local/bin/claude-tools/claude-context-manager.sh'
alias claude-load='~/.local/bin/claude-tools/claude-context-loader.sh'
alias claude-init='~/.local/bin/claude-tools/claude-project-init.sh'
alias claude-switch='~/.local/bin/claude-tools/claude-context-switcher.sh'
```

## File Sizes Reference

Approximate sizes for verification:

```
claude-context-manager.sh       ~6-7 KB
claude-context-loader.sh        ~5 KB
claude-context-switcher.sh      ~5-6 KB
claude-project-init.sh          ~7-8 KB
shell-config.sh                 ~7-8 KB
install.sh                      ~12 KB
```

## Common Issues

### "Script not found" during install.sh

**Problem:** You're running install.sh from a directory that doesn't contain the other scripts.

**Solution:**
```bash
# Make sure you're in the directory with all the files
cd /path/to/downloaded/files
ls -la *.sh
# You should see all 4-7 .sh files

# Then run install
./install.sh
```

### Missing some scripts

**Problem:** Some .sh files are missing from your download.

**Solution:** Download all files from the outputs directory. All files should be available.

### Permission denied

**Problem:** Scripts aren't executable.

**Solution:**
```bash
chmod +x *.sh
```

## Directory Structure After Download

Your download directory should look like:

```
your-download-dir/
├── claude-context-manager.sh       ← REQUIRED
├── claude-context-loader.sh        ← REQUIRED
├── claude-context-switcher.sh      ← REQUIRED
├── claude-project-init.sh          ← REQUIRED
├── shell-config.sh                 ← Recommended
├── install.sh                      ← Recommended (auto-installer)
├── verify-files.sh                 ← Optional (checks files)
├── README.md                       ← Optional
├── COMPLETE_GUIDE.md               ← Optional
├── DEPLOYMENT_GUIDE.md             ← Optional
├── QUICK_INSTALL.md                ← Optional
└── project-instructions-template.md ← Optional
```

## Verification Command

To verify all files are present and ready:

```bash
cd /path/to/downloaded/files

# Check files exist
ls -1 claude-*.sh

# Should show:
# claude-context-manager.sh
# claude-context-loader.sh
# claude-context-switcher.sh
# claude-project-init.sh

# Check they're executable
ls -l claude-*.sh

# If not executable, fix it:
chmod +x *.sh

# Then run installer:
./install.sh
```
