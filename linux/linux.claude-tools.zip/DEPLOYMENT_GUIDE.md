# Deployment & Installation Guide

## 🎯 Where to Deploy

You have several options for deploying these scripts:

### Option 1: User-Local Installation (Recommended)
**Location:** `~/.local/bin/claude-tools/`

**Pros:**
- ✅ No sudo required
- ✅ User-specific, won't affect others
- ✅ Easy to update/remove
- ✅ Standard Linux convention

**Cons:**
- ❌ Only available to your user

### Option 2: Home Binary Directory
**Location:** `~/bin/`

**Pros:**
- ✅ Simple and clean
- ✅ No sudo required
- ✅ Traditional location

**Cons:**
- ❌ Only available to your user
- ❌ May need PATH configuration

### Option 3: System-Wide Installation
**Location:** `/usr/local/bin/`

**Pros:**
- ✅ Available to all users
- ✅ Standard system location
- ✅ Automatically in PATH

**Cons:**
- ❌ Requires sudo
- ❌ Needs admin access to update

---

## 🚀 Quick Installation (Automated)

### Method 1: Use the Installation Script

```bash
# 1. Download all files to a temporary directory
mkdir -p ~/downloads/claude-tools
cd ~/downloads/claude-tools

# (Copy all the .sh files here)

# 2. Make the installer executable
chmod +x install.sh

# 3. Run the installer
./install.sh
```

The installer will:
- ✅ Let you choose installation location
- ✅ Install all scripts
- ✅ Create command aliases (claude-save, claude-load, etc.)
- ✅ Configure your shell (.bashrc or .zshrc)
- ✅ Set up initial project configuration

---

## 🛠️ Manual Installation

### Step 1: Download the Scripts

Create a directory and save all these files:

```bash
mkdir -p ~/claude-tools-install
cd ~/claude-tools-install
```

**Required files:**
- `claude-context-manager.sh`
- `claude-context-loader.sh`
- `claude-context-switcher.sh`
- `claude-project-init.sh`
- `shell-config.sh`
- `project-instructions-template.md`
- `COMPLETE_GUIDE.md`

### Step 2: Choose Installation Directory

**Option A: User-local (Recommended)**
```bash
INSTALL_DIR="$HOME/.local/bin/claude-tools"
mkdir -p "$INSTALL_DIR"
```

**Option B: User bin**
```bash
INSTALL_DIR="$HOME/bin"
mkdir -p "$INSTALL_DIR"
```

**Option C: System-wide**
```bash
INSTALL_DIR="/usr/local/bin"
# Will need sudo for copying files
```

### Step 3: Copy Files

```bash
# Copy all scripts
cp *.sh "$INSTALL_DIR/"

# Copy documentation and templates
cp *.md "$INSTALL_DIR/"

# Make scripts executable
chmod +x "$INSTALL_DIR"/*.sh
```

If using system-wide installation:
```bash
sudo cp *.sh "$INSTALL_DIR/"
sudo cp *.md "$INSTALL_DIR/"
sudo chmod +x "$INSTALL_DIR"/*.sh
```

### Step 4: Create Command Aliases

```bash
# Create a bin directory for symlinks (if it doesn't exist)
mkdir -p "$HOME/.local/bin"

# Create symlinks for easy access
ln -sf "$INSTALL_DIR/claude-context-manager.sh" "$HOME/.local/bin/claude-save"
ln -sf "$INSTALL_DIR/claude-context-loader.sh" "$HOME/.local/bin/claude-load"
ln -sf "$INSTALL_DIR/claude-context-switcher.sh" "$HOME/.local/bin/claude-switch"
ln -sf "$INSTALL_DIR/claude-project-init.sh" "$HOME/.local/bin/claude-init"
```

### Step 5: Configure Your Shell

**For Bash** (edit `~/.bashrc`):

```bash
# Add to end of ~/.bashrc

# ============================================================================
# Claude Code Context Management
# ============================================================================

# Add to PATH
export PATH="$HOME/.local/bin:$PATH"

# Source shell integration
source "$HOME/.local/bin/claude-tools/shell-config.sh"

# Or add minimal aliases
alias claude-save='~/.local/bin/claude-tools/claude-context-manager.sh'
alias claude-load='~/.local/bin/claude-tools/claude-context-loader.sh'
alias claude-init='~/.local/bin/claude-tools/claude-project-init.sh'
alias claude-switch='~/.local/bin/claude-tools/claude-context-switcher.sh'

# Set your projects directory
export CLAUDE_PROJECTS_DIR="$HOME/projects"
```

**For Zsh** (edit `~/.zshrc`):

```bash
# Add to end of ~/.zshrc

# ============================================================================
# Claude Code Context Management
# ============================================================================

# Add to PATH
export PATH="$HOME/.local/bin:$PATH"

# Source shell integration
source "$HOME/.local/bin/claude-tools/shell-config.sh"

# Set your projects directory
export CLAUDE_PROJECTS_DIR="$HOME/projects"
```

### Step 6: Reload Shell Configuration

```bash
# For Bash
source ~/.bashrc

# For Zsh
source ~/.zshrc
```

### Step 7: Verify Installation

```bash
# Check if commands are available
which claude-save
which claude-load
which claude-init

# Test a command
claude-save --help
```

---

## 📂 Directory Structure After Installation

### User-Local Installation
```
$HOME/
├── .local/
│   └── bin/
│       ├── claude-tools/              # Installation directory
│       │   ├── claude-context-manager.sh
│       │   ├── claude-context-loader.sh
│       │   ├── claude-context-switcher.sh
│       │   ├── claude-project-init.sh
│       │   ├── shell-config.sh
│       │   └── COMPLETE_GUIDE.md
│       ├── claude-save -> ../claude-tools/claude-context-manager.sh
│       ├── claude-load -> ../claude-tools/claude-context-loader.sh
│       ├── claude-init -> ../claude-tools/claude-project-init.sh
│       └── claude-switch -> ../claude-tools/claude-context-switcher.sh
├── .bashrc or .zshrc                 # Updated with configuration
└── .claude-projects.conf             # Project list (created on first use)
```

### System-Wide Installation
```
/usr/local/bin/
├── claude-context-manager.sh
├── claude-context-loader.sh
├── claude-context-switcher.sh
├── claude-project-init.sh
└── shell-config.sh

$HOME/
├── .bashrc or .zshrc                 # Updated with configuration
└── .claude-projects.conf             # Project list
```

---

## 🔧 Platform-Specific Instructions

### Ubuntu / Debian

```bash
# Install using apt (if using system directories)
sudo apt-get update

# Create user bin directory
mkdir -p ~/.local/bin

# Follow standard installation above
```

### macOS

```bash
# If using Homebrew, you can create a formula (advanced)
# Or just use standard installation to ~/.local/bin

# For zsh (default on macOS)
# Edit ~/.zshrc instead of ~/.bashrc
```

### WSL (Windows Subsystem for Linux)

```bash
# Same as Ubuntu/Debian
# Make sure scripts are in a Linux filesystem, not /mnt/c/

# Recommended location:
INSTALL_DIR="$HOME/.local/bin/claude-tools"
```

### Arch Linux / Manjaro

```bash
# Same as standard installation
# Optionally create a PKGBUILD (advanced)
```

---

## 🎯 Minimal Installation (No Shell Integration)

If you don't want shell integration, just want the scripts:

```bash
# 1. Create directory
mkdir -p ~/bin/claude-tools

# 2. Copy scripts
cp *.sh ~/bin/claude-tools/
chmod +x ~/bin/claude-tools/*.sh

# 3. Use full paths
~/bin/claude-tools/claude-context-manager.sh
~/bin/claude-tools/claude-context-loader.sh
```

---

## 🐳 Docker Installation (Isolated Environment)

Create a Dockerfile:

```dockerfile
FROM ubuntu:22.04

# Install dependencies
RUN apt-get update && apt-get install -y \
    git \
    curl \
    && rm -rf /var/lib/apt/lists/*

# Copy scripts
COPY *.sh /usr/local/bin/claude-tools/
COPY *.md /usr/local/bin/claude-tools/

# Make executable
RUN chmod +x /usr/local/bin/claude-tools/*.sh

# Add to PATH
ENV PATH="/usr/local/bin/claude-tools:${PATH}"

# Create symlinks
RUN ln -s /usr/local/bin/claude-tools/claude-context-manager.sh /usr/local/bin/claude-save && \
    ln -s /usr/local/bin/claude-tools/claude-context-loader.sh /usr/local/bin/claude-load && \
    ln -s /usr/local/bin/claude-tools/claude-project-init.sh /usr/local/bin/claude-init

WORKDIR /workspace
```

---

## 🔄 Updating the Scripts

### If Installed via install.sh

```bash
# Re-run the installer
cd ~/downloads/claude-tools
./install.sh
# Choose same installation directory when prompted
```

### If Installed Manually

```bash
# Download new versions
cd ~/claude-tools-install

# Copy to installation directory
cp *.sh "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR"/*.sh

# Reload shell
source ~/.bashrc  # or ~/.zshrc
```

---

## 🗑️ Uninstallation

### Remove Scripts

```bash
# Remove installation directory
rm -rf "$HOME/.local/bin/claude-tools"

# Remove symlinks
rm -f "$HOME/.local/bin/claude-save"
rm -f "$HOME/.local/bin/claude-load"
rm -f "$HOME/.local/bin/claude-init"
rm -f "$HOME/.local/bin/claude-switch"

# Remove config file
rm -f "$HOME/.claude-projects.conf"
```

### Remove Shell Configuration

Edit `~/.bashrc` or `~/.zshrc` and remove the section:

```bash
# Remove this entire block:
# ============================================================================
# Claude Code Context Management
# ============================================================================
# ... everything between the comment blocks
```

Then reload:
```bash
source ~/.bashrc  # or ~/.zshrc
```

### Remove Project Data (Optional)

```bash
# Remove saved transcripts from all projects
# WARNING: This deletes conversation history!

find ~/projects -type d -name "claude_transcripts" -exec rm -rf {} +
find ~/projects -type d -name ".claude" -exec rm -rf {} +
find ~/projects -type f -name "claude-resume.sh" -delete
```

---

## ✅ Post-Installation Checklist

- [ ] All scripts copied to installation directory
- [ ] Scripts are executable (`chmod +x`)
- [ ] Symlinks created in `~/.local/bin`
- [ ] `~/.local/bin` is in your PATH
- [ ] Shell configuration updated
- [ ] Shell configuration reloaded (`source ~/.bashrc`)
- [ ] Commands work (`claude-save --help`)
- [ ] Claude Code is installed (`claudecode --version`)
- [ ] First project initialized (`claude-init`)

---

## 🆘 Troubleshooting

### "Command not found: claude-save"

**Solution 1: Check PATH**
```bash
echo $PATH | grep ".local/bin"
# If not found, add to PATH:
export PATH="$HOME/.local/bin:$PATH"
```

**Solution 2: Use full path**
```bash
~/.local/bin/claude-save
```

**Solution 3: Reload shell config**
```bash
source ~/.bashrc  # or ~/.zshrc
```

### "Permission denied"

```bash
# Make scripts executable
chmod +x ~/.local/bin/claude-tools/*.sh
```

### Scripts don't work after installation

```bash
# Check file locations
ls -la ~/.local/bin/claude-tools/
ls -la ~/.local/bin/claude-*

# Check if symlinks are correct
ls -la ~/.local/bin/ | grep claude

# Verify shell config
grep -A 10 "Claude Code" ~/.bashrc
```

### Shell integration not working

```bash
# Verify shell type
echo $SHELL

# Check if config file is being loaded
# Add this line to ~/.bashrc and restart terminal:
echo "Loading .bashrc"

# If using bash, might need ~/.bash_profile instead
```

---

## 📝 Quick Reference

### Installation Locations

| Location | Command | Scope | Sudo? |
|----------|---------|-------|-------|
| `~/.local/bin/claude-tools/` | Recommended | User | No |
| `~/bin/` | Simple | User | No |
| `/usr/local/bin/` | System-wide | All users | Yes |

### Files to Deploy

| File | Purpose | Required? |
|------|---------|-----------|
| `claude-context-manager.sh` | Save context | ✅ Yes |
| `claude-context-loader.sh` | Load context | ✅ Yes |
| `claude-context-switcher.sh` | Multi-project | ✅ Yes |
| `claude-project-init.sh` | Initialize project | ✅ Yes |
| `shell-config.sh` | Shell integration | ⚠️ Optional |
| `install.sh` | Automated installer | ⚠️ Optional |
| `COMPLETE_GUIDE.md` | Documentation | ⚠️ Optional |
| `project-instructions-template.md` | Template | ⚠️ Optional |

---

## 🎓 Next Steps After Installation

1. **Initialize your first project:**
   ```bash
   cd ~/projects/my-project
   claude-init
   ```

2. **Edit project instructions:**
   ```bash
   nano .claude/instructions.md
   ```

3. **Start working:**
   ```bash
   ./claude-resume.sh
   ```

4. **Read the full guide:**
   ```bash
   cat ~/.local/bin/claude-tools/COMPLETE_GUIDE.md
   ```
