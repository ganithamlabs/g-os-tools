#!/bin/bash

# Claude Code Project Initializer
# Sets up a new project for Claude context management

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_step() { echo -e "${BLUE}[STEP]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }

# Initialize a project for Claude context management
init_project() {
    local project_path="${1:-.}"
    cd "$project_path"
    
    local repo_root=$(git rev-parse --show-toplevel 2>/dev/null || echo "$(pwd)")
    local repo_name=$(basename "$repo_root")
    
    echo "╔════════════════════════════════════════════════╗"
    echo "║   Claude Code Project Initializer             ║"
    echo "╚════════════════════════════════════════════════╝"
    echo ""
    print_step "Initializing: $repo_name"
    echo ""
    
    # Create claude_transcripts directory
    print_step "Creating transcript directory..."
    mkdir -p "$repo_root/claude_transcripts"
    
    # Create .claude directory for custom instructions
    print_step "Creating .claude configuration directory..."
    mkdir -p "$repo_root/.claude"
    
    # Create custom instructions file
    if [ ! -f "$repo_root/.claude/instructions.md" ]; then
        print_step "Creating custom instructions template..."
        
        cat > "$repo_root/.claude/instructions.md" << EOF
# Project: $repo_name

## Project Overview

**Description:** [Add project description]

**Type:** [Web app / API / CLI tool / Library]

**Status:** [Active development / Maintenance]

## Tech Stack

**Primary Language:** [Language]
**Framework:** [Framework]
**Key Dependencies:** [List main dependencies]

## Architecture & Patterns

[Describe your architecture and key patterns Claude should follow]

## Coding Conventions

- [Convention 1]
- [Convention 2]

## Current Work

**Focus:** [What you're currently working on]

**Next Steps:**
- [ ] [Task 1]
- [ ] [Task 2]

## Important Context

**Things Claude Should Know:**
- [Important note]

**Things to Avoid:**
- [Anti-pattern]

## Common Commands

\`\`\`bash
# Development
npm start

# Testing
npm test

# Build
npm run build
\`\`\`

---

**Last Updated:** $(date +%Y-%m-%d)
EOF
        
        print_info "Created: .claude/instructions.md"
        print_info "Edit this file to customize Claude's understanding of your project"
    else
        print_info ".claude/instructions.md already exists"
    fi
    
    # Create README for transcripts
    if [ ! -f "$repo_root/claude_transcripts/README.md" ]; then
        cat > "$repo_root/claude_transcripts/README.md" << EOF
# Claude Code Transcripts

This directory contains conversation history with Claude Code for this project.

## Purpose

These transcripts help maintain context across sessions by preserving:
- Design decisions made with Claude
- Code solutions implemented
- Debugging sessions
- Architecture discussions

## Usage

The transcripts are automatically managed by the Claude context scripts:
- **Save context:** Run \`claude-save\` before switching projects
- **Load context:** Run \`claude-load\` when resuming work

## Files

Transcript files are named with timestamps: \`transcript_YYYYMMDD_HHMMSS.json\`

---

**Project:** $repo_name
**Initialized:** $(date)
EOF
        print_info "Created: claude_transcripts/README.md"
    fi
    
    # Create .gitignore entry for transcripts (optional)
    if [ -f "$repo_root/.gitignore" ]; then
        if ! grep -q "claude_transcripts" "$repo_root/.gitignore"; then
            echo ""
            read -p "Add claude_transcripts/ to .gitignore? (y/N): " -n 1 -r
            echo
            if [[ $REPLY =~ ^[Yy]$ ]]; then
                echo "" >> "$repo_root/.gitignore"
                echo "# Claude Code transcripts (optional - remove if you want to commit them)" >> "$repo_root/.gitignore"
                echo "claude_transcripts/" >> "$repo_root/.gitignore"
                print_info "Added to .gitignore"
            fi
        fi
    fi
    
    # Create a project-specific loader script
    cat > "$repo_root/claude-resume.sh" << 'EOF'
#!/bin/bash
# Quick script to resume work on this project with Claude Code

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "🔄 Loading Claude Code context for this project..."
~/claude-context-loader.sh

echo ""
echo "✅ Context loaded! Starting Claude Code..."
echo ""

cd "$SCRIPT_DIR"
claudecode
EOF
    
    chmod +x "$repo_root/claude-resume.sh"
    print_info "Created: claude-resume.sh (quick start script)"
    
    # Create project summary
    cat > "$repo_root/.claude/PROJECT_CONTEXT.md" << EOF
# Project Context for Claude Code

**Project:** $repo_name
**Path:** $repo_root
**Initialized:** $(date)

## Quick Start

To resume work with Claude Code:
\`\`\`bash
./claude-resume.sh
\`\`\`

Or manually:
\`\`\`bash
claude-load  # Load saved context
claudecode   # Start coding
\`\`\`

## Context Management

**Save context before switching:**
\`\`\`bash
claude-save
\`\`\`

**Load context when resuming:**
\`\`\`bash
claude-load
\`\`\`

## Files

- \`.claude/instructions.md\` - Project-specific instructions for Claude
- \`claude_transcripts/\` - Saved conversation history
- \`claude-resume.sh\` - Quick start script

## Tips

1. Update \`.claude/instructions.md\` with important project context
2. Save context regularly when switching between projects
3. Review transcripts to understand previous decisions

---

Auto-generated by claude-project-init.sh
EOF
    
    print_info "Created: .claude/PROJECT_CONTEXT.md"
    
    # Summary
    echo ""
    echo "════════════════════════════════════════════════"
    print_info "✅ Project initialized for Claude Code!"
    echo ""
    echo "📁 Created files:"
    echo "   - .claude/instructions.md (customize this!)"
    echo "   - .claude/PROJECT_CONTEXT.md"
    echo "   - claude_transcripts/README.md"
    echo "   - claude-resume.sh"
    echo ""
    echo "🚀 Next steps:"
    echo "   1. Edit .claude/instructions.md with project details"
    echo "   2. Run: ./claude-resume.sh to start coding"
    echo "   3. Run: claude-save before switching to other projects"
    echo ""
    echo "💡 Quick commands:"
    echo "   - Start work: ./claude-resume.sh"
    echo "   - Load context: claude-load"
    echo "   - Save context: claude-save"
    echo "════════════════════════════════════════════════"
}

# Show help
show_help() {
    cat << 'EOF'
Claude Code Project Initializer

Usage:
  ./claude-project-init.sh [PROJECT_PATH]

Examples:
  # Initialize current directory
  ./claude-project-init.sh
  
  # Initialize specific project
  ./claude-project-init.sh /path/to/project

This will create:
  - .claude/instructions.md - Custom instructions for Claude
  - .claude/PROJECT_CONTEXT.md - Project context guide
  - claude_transcripts/ - Directory for saved conversations
  - claude-resume.sh - Quick start script
EOF
}

# Main
case "${1:-}" in
    --help|-h)
        show_help
        ;;
    *)
        init_project "$@"
        ;;
esac
